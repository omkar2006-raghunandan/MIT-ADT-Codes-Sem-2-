import shapes
print("Choose shape: ")
print("1. Circle")
print("2. Rectangle")
print("3. Triangle")

choice = int(input("Enter your choice (1-3): "))

if choice == 1:
    r = float(input("Enter radius: "))
    area = shapes.circle_area(r)
    print(f"Area of Circle is{area}")

elif choice == 2:
    b = float(input("Enter base: "))
    h = float(input("Enter height: "))
    area = shapes.triangle_area(b,h)
    print("Area of Triangle =", area)

else:
    print("Invalid Choice")